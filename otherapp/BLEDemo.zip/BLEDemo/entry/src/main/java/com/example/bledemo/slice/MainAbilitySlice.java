package com.example.bledemo.slice;

import com.example.bledemo.ResourceTable;
import ohos.aafwk.ability.AbilitySlice;
import ohos.aafwk.content.Intent;
import ohos.bluetooth.ble.BleCentralManager;
import ohos.bluetooth.ble.BleCentralManagerCallback;
import ohos.bluetooth.ble.BleScanFilter;
import ohos.bluetooth.ble.BleScanResult;
import ohos.hiviewdfx.HiLog;

import java.util.ArrayList;
import java.util.List;

public class MainAbilitySlice extends AbilitySlice {
    static  String TAG = "MainAbilitySlice";
    private ScanCallback centralManagerCallback = new ScanCallback();
    private BleCentralManager centralManager;
    @Override
    public void onStart(Intent intent) {
        super.onStart(intent);
        super.setUIContent(ResourceTable.Layout_ability_main);

        startScan();
    }

    // 实现扫描回调
    public class ScanCallback implements BleCentralManagerCallback {
        List<BleScanResult> results = new ArrayList<BleScanResult>();
        @Override
        public void scanResultEvent(BleScanResult bleScanResult) {
            // 对扫描结果进行处理
            results.add(bleScanResult);
        }

        @Override
        public void scanFailedEvent(int i) {
//            HiLog.info(TAG,"Start Scan failed,Code:" + i);
        }

        @Override
        public void groupScanResultsEvent(List<BleScanResult> list) {

        }
    }

    private void startScan() {
        // 获取中心设备管理对象
        centralManager = new BleCentralManager(getContext(), centralManagerCallback);
        // 创建扫描过滤器然后开始扫描
        List<BleScanFilter> filters = new ArrayList<BleScanFilter>();
        centralManager.startScan(filters);
    }

    @Override
    public void onActive() {
        super.onActive();
    }

    @Override
    public void onForeground(Intent intent) {
        super.onForeground(intent);
    }
}
