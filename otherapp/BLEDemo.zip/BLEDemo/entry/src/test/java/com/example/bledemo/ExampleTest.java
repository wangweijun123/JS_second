package com.example.bledemo;

import org.junit.Test;

public class ExampleTest {
    @Test
    public void onStart() {
    }
}
