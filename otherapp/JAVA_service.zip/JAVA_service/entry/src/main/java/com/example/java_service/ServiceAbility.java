package com.example.java_service;

import ohos.aafwk.ability.Ability;
import ohos.aafwk.content.Intent;
import ohos.hiviewdfx.HiLog;
import ohos.hiviewdfx.HiLogLabel;
import ohos.rpc.*;

public class ServiceAbility extends Ability {
    public static final HiLogLabel LABEL_LOG = new HiLogLabel(3, 0xD001100, "MainAbility");

    @Override
    public void onStart(Intent intent) {
        super.onStart(intent);
    }


    @Override
    public void onCommand(Intent intent, boolean restart, int startId) {
        super.onCommand(intent, restart, startId);
    }


    @Override
    public IRemoteObject onConnect(Intent intent) {
        super.onConnect(intent);
        return new MyRemoteObject();
    }


    @Override
    public void onDisconnect(Intent intent) {
        super.onDisconnect(intent);
    }


    @Override
    public void onStop() {
        super.onStop();
    }

    // 创建自定义IRemoteObject实现类
    private class MyRemoteObject extends MyIdlInterfaceStub {
        public MyRemoteObject() {
            super("MyRemoteObject");
        }
        @Override
        public void serviceMethod1(int anInt) throws RemoteException {

        }

        @Override
        public int plus(int num1, int num2) throws RemoteException {
            HiLog.info(LABEL_LOG, "server " + num1 + " " + num2);
            return num1 + num2;
        }
    }
}
