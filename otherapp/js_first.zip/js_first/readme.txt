1 hml 中if控制标签是否显示
2 comfig.json  js页面的顺序控制的主页
3 js 调用 java 的内部(进程内)的service 与其他的应用的service